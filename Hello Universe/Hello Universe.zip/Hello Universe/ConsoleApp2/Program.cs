﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2 // its our solution name 
{
    class Program //its our main class 
    {
        static void Main(string[] args) // and this our main method 
        {
            //today i gonna show you your first c# dot net console programm 
            // you already know every progamming language they follow there main function/method 
            // C3 dot net is object oriented progamming language like java and they follow bottom up procedure 

            Console.WriteLine("Hello Universe ");

            Console.Write("Hello Universe =,");
            Console.Write("Hello World =,");
            Console.Write("Hello Bangladesh=,");
            // ok good by see yea again in next class 

            Console.ReadKey();
            
           
        }
    }
}
